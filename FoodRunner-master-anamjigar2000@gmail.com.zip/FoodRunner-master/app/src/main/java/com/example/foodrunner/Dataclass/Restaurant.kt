package com.example.foodrunner.Dataclass

data class Restaurant (

    val id : String,
    val name : String,
    val rating : String,
    val price : String,
    val image : String
)
